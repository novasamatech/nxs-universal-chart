# NUC Envoy Gateway

Helm chart for rendering Envoy Gateway extension resources from declarative values.

The chart does not install Envoy Gateway CRDs or the Envoy Gateway controller. It only renders Envoy Gateway custom resources that are already supported by the target cluster.

## Quick Start

Render the example configuration:

```bash
helm template nuc-envoy-gateway . -f values.yaml.example
```

Install the chart:

```bash
helm install nuc-envoy-gateway . \
  --namespace envoy-gateway-system \
  --create-namespace \
  -f values.yaml.example
```

Install the local README generator hook:

```bash
pre-commit install
pre-commit install-hooks
```

## Supported Resources

The chart can render these Envoy Gateway kinds:

- `Backend`
- `BackendTrafficPolicy`
- `ClientTrafficPolicy`
- `EnvoyExtensionPolicy`
- `EnvoyPatchPolicy`
- `EnvoyProxy`
- `HTTPRouteFilter`
- `SecurityPolicy`

Support for individual fields still depends on the CRDs and controller version installed in the cluster.

## Values Model

Each top-level map in [values.yaml](values.yaml) maps resource names to one Envoy Gateway kind:

- `backends`
- `backendTrafficPolicies`
- `clientTrafficPolicies`
- `envoyExtensionPolicies`
- `envoyPatchPolicies`
- `envoyProxies`
- `httpRouteFilters`
- `securityPolicies`

Every map entry uses the same generic contract:

| Field | Required | Description |
|-------|----------|-------------|
| map key | yes | Resource name used for `metadata.name`. |
| `namespace` | no | Namespace for namespaced resources. Defaults to the Helm release namespace. |
| `labels` | no | Labels merged on top of built-in chart labels and `commonLabels`. |
| `annotations` | no | Annotations merged on top of `commonAnnotations`. |
| `apiVersion` | no | Per-resource API version override. |
| `spec` | no | Resource spec rendered as-is and validated against the upstream Envoy Gateway CRD schema. |
| `status` | no | Optional raw status block. Usually not managed through Helm in production. |

Global controls:

- `nameOverride`
- `commonLabels`
- `commonAnnotations`
- `apiVersions.*`

The value contract is validated by [values.schema.json](values.schema.json).

## Helm Values

This section is generated from [values.yaml](values.yaml) by `helm-docs`. Edit [values.yaml](values.yaml) comments or [docs/README.md.gotmpl](docs/README.md.gotmpl), then run `pre-commit run helm-docs --all-files` or `make docs` if you need to refresh it outside a commit.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| apiVersions.backend | string | `"gateway.envoyproxy.io/v1alpha1"` | Default apiVersion for Backend resources. |
| apiVersions.backendTrafficPolicy | string | `"gateway.envoyproxy.io/v1alpha1"` | Default apiVersion for BackendTrafficPolicy resources. |
| apiVersions.clientTrafficPolicy | string | `"gateway.envoyproxy.io/v1alpha1"` | Default apiVersion for ClientTrafficPolicy resources. |
| apiVersions.envoyExtensionPolicy | string | `"gateway.envoyproxy.io/v1alpha1"` | Default apiVersion for EnvoyExtensionPolicy resources. |
| apiVersions.envoyPatchPolicy | string | `"gateway.envoyproxy.io/v1alpha1"` | Default apiVersion for EnvoyPatchPolicy resources. |
| apiVersions.envoyProxy | string | `"gateway.envoyproxy.io/v1alpha1"` | Default apiVersion for EnvoyProxy resources. |
| apiVersions.httpRouteFilter | string | `"gateway.envoyproxy.io/v1alpha1"` | Default apiVersion for HTTPRouteFilter resources. |
| apiVersions.securityPolicy | string | `"gateway.envoyproxy.io/v1alpha1"` | Default apiVersion for SecurityPolicy resources. |
| backends | object | {} | Backend resources keyed by resource name. |
| backends.__helm_docs_example__.annotations | object | `{}` | Resource-specific annotations. |
| backends.__helm_docs_example__.apiVersion | string | chart default for this kind | Per-resource apiVersion override. |
| backends.__helm_docs_example__.labels | object | `{}` | Resource-specific labels. |
| backends.__helm_docs_example__.namespace | string | release namespace | Namespace for namespaced resources. Defaults to the Helm release namespace. |
| backends.__helm_docs_example__.spec | object | `{"appProtocols":["gateway.envoyproxy.io/h2c"]}` | Resource spec rendered as-is and validated against the upstream CRD schema. |
| backends.__helm_docs_example__.spec.appProtocols | list | `["gateway.envoyproxy.io/h2c"]` | AppProtocols defines the application protocols to be supported when connecting to the backend. |
| commonAnnotations | object | `{}` | Extra annotations applied to every rendered resource. |
| commonLabels | object | `{}` | Extra labels applied to every rendered resource. |
| nameOverride | string | `""` | Override the default chart label name if needed. |

## Included Values Files

- [values.yaml](values.yaml): defaults and `helm-docs` source comments.
- [values.yaml.example](values.yaml.example): example configuration covering every supported resource type.

## Testing

The repository uses three test layers:

- `tests/units/` for `helm-unittest` suites and backward compatibility checks
- `tests/e2e/` for local kind-based Helm install checks against vendored Envoy Gateway CRDs
- `tests/smokes/` for render and schema smoke scenarios

Representative local commands:

```bash
helm lint . -f values.yaml.example
helm template nuc-envoy-gateway . -f values.yaml.example
helm unittest -f 'tests/units/*_test.yaml' .
sh tests/units/backward_compatibility_test.sh
python3 tests/smokes/run/smoke.py --scenario example-render
make test-e2e
```

Detailed test documentation is available in [docs/TESTS.MD](docs/TESTS.MD).

## Notes

- Keep the chart API versions aligned with the Envoy Gateway CRDs installed in the cluster.
- The e2e layer applies vendored CRDs from `tests/e2e/crds/` so it can validate the rendered objects without installing the controller itself.
- Prefer managing `spec` through Helm and let the controller own `status`.

## Repository Layout

| Path | Purpose |
|------|---------|
| [Chart.yaml](Chart.yaml) | Chart metadata. |
| [values.yaml](values.yaml) | Defaults and `helm-docs` source comments. |
| [docs/README.md.gotmpl](docs/README.md.gotmpl) | Template used by `helm-docs` to build `README.md`. |
| [values.yaml.example](values.yaml.example) | Example configuration. |
| [values.schema.json](values.schema.json) | JSON schema for chart values. |
| [templates/](templates) | One template per supported Envoy Gateway kind plus shared helpers. |
| [tests/units/](tests/units) | Compact Helm unit suites and backward compatibility checks. |
| [tests/e2e/](tests/e2e) | kind-based end-to-end installation checks. |
| [tests/smokes/](tests/smokes) | Smoke scenarios for render and schema validation. |
| [docs/DEPENDENCY.md](docs/DEPENDENCY.md) | Local dependency installation guide for development and tests. |
| [docs/TESTS.MD](docs/TESTS.MD) | Detailed testing documentation. |
