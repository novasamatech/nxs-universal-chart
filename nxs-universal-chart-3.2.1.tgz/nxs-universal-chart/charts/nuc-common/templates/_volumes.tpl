{{- define "helpers.volumes.typed" -}}
{{- $ctx := .context -}}
{{- range .volumes -}}
{{- if eq .type "configMap" }}
- name: {{ .name }}
  configMap:
    {{- with (.configMapName | default .originalName) }}
    name: {{ . }}
    {{- else }}
    name: {{ include "helpers.app.fullname" (dict "name" .name "context" $ctx) }}
    {{- end }}
    {{- with .defaultMode }}
    defaultMode: {{ . }}
    {{- end }}
    {{- with .items }}
    items: {{- include "helpers.tplvalues.render" (dict "value" . "context" $ctx) | nindent 6 }}
    {{- end }}
{{- else if eq .type "secret" }}
- name: {{ .name }}
  secret:
    {{- with (.secretName | default .originalName) }}
    secretName: {{ . }}
    {{- else }}
    secretName: {{ include "helpers.app.fullname" (dict "name" .name "context" $ctx) }}
    {{- end }}
    {{- with .items }}
    items: {{- include "helpers.tplvalues.render" (dict "value" . "context" $ctx) | nindent 6 }}
    {{- end }}
{{- else if eq .type "pvc" }}
- name: {{ .name }}
  persistentVolumeClaim:
    {{- with (.claimName | default .originalName) }}
    claimName: {{ . }}
    {{- else }}
    claimName: {{ include "helpers.app.fullname" (dict "name" .name "context" $ctx) }}
    {{- end }}
{{- else if eq .type "emptyDir" }}
- name: {{ .name }}
  {{- if or .sizeLimit .medium }}
  emptyDir:
    {{- if .sizeLimit }}
    sizeLimit: {{ .sizeLimit }}
    {{- end }}
    {{- if .medium }}
    medium: {{ .medium }}
    {{- end }}
  {{- else }}
  emptyDir: {}
  {{- end }}
{{- else if eq .type "projected" }}
- name: {{ .name }}
  projected:
    {{- with .defaultMode }}
    defaultMode: {{ . }}
    {{- end }}
    sources: {{- include "helpers.tplvalues.render" (dict "value" (.sources | default list) "context" $ctx) | nindent 6 }}
{{- end }}
{{- end -}}
{{- end -}}

{{- define "helpers.volumes.renderVolume" -}}
{{- $ctx := .context -}}
{{- $general := .general | default dict -}}
{{- $val := .value | default dict -}}
{{- if or $val.volumes $general.volumes $ctx.Values.generic.volumes $val.extraVolumes $general.extraVolumes $ctx.Values.generic.extraVolumes -}}
{{- with $val.volumes }}
{{ include "helpers.volumes.typed" (dict "volumes" . "context" $ctx) }}
{{- end }}
{{- with $general.volumes }}
{{ include "helpers.volumes.typed" (dict "volumes" . "context" $ctx) }}
{{- end }}
{{- with $ctx.Values.generic.volumes }}
{{ include "helpers.volumes.typed" (dict "volumes" . "context" $ctx) }}
{{- end }}
{{- with $val.extraVolumes }}
{{ include "helpers.tplvalues.render" (dict "value" . "context" $ctx) }}
{{- end }}
{{- with $general.extraVolumes }}
{{ include "helpers.tplvalues.render" (dict "value" . "context" $ctx) }}
{{- end }}
{{- with $ctx.Values.generic.extraVolumes }}
{{ include "helpers.tplvalues.render" (dict "value" . "context" $ctx) }}
{{- end }}
{{- else -}}
[]
{{- end -}}
{{- end -}}

{{- define "helpers.volumes.renderVolumeMounts" -}}
{{- $ctx := .context -}}
{{- $general := .general | default dict -}}
{{- $val := .value | default dict -}}
{{- if or $val.volumeMounts $val.extraVolumeMounts $general.volumeMounts $general.extraVolumeMounts $ctx.Values.generic.volumeMounts $ctx.Values.generic.extraVolumeMounts -}}
{{- with $val.volumeMounts }}
{{ include "helpers.tplvalues.render" (dict "value" . "context" $ctx) }}
{{- end }}
{{- with $val.extraVolumeMounts }}
{{ include "helpers.tplvalues.render" (dict "value" . "context" $ctx) }}
{{- end }}
{{- with $general.volumeMounts }}
{{ include "helpers.tplvalues.render" (dict "value" . "context" $ctx) }}
{{- end }}
{{- with $general.extraVolumeMounts }}
{{ include "helpers.tplvalues.render" (dict "value" . "context" $ctx) }}
{{- end }}
{{- with $ctx.Values.generic.volumeMounts }}
{{ include "helpers.tplvalues.render" (dict "value" . "context" $ctx) }}
{{- end }}
{{- with $ctx.Values.generic.extraVolumeMounts }}
{{ include "helpers.tplvalues.render" (dict "value" . "context" $ctx) }}
{{- end }}
{{- else -}}
[]
{{- end -}}
{{- end -}}
